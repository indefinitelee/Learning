First thing I did was look over the data and make sure I understood it. 

OK we've got 10 topics rated on a single aspect, "most important". There isn't any ranking of choices - each respondant stated either a topic or "don't know". 

The cohort that rated a topic as most important is broken down into 7 demographic categories, each sub-divided into several attributes, for a total of 26 attributes tracked in this survey and data table. 

We are interested in a visual representation of the horizontal rows (Who rates topic X most important?) but also of the vertical columns (What is most important to group X?). 

So rows answer "Who?" 
Columns asnwer "What"?

Next I did some Googling and review of my Tufte books to see how this type of data has been represented in the past. Because good artists borrow, and great artists steal. 

From what I found at sites like the NY Times, 538, and Pew Research a dataset like this is often shown as a table with line graphs calling out specific relationships. 

I don't think this is a bad way to do it. From baseball standings to stock pages, people are pretty good at reading and understanding tables. 

But this is not a very ~interesting~ approach. 

I want something that will show magnitude and hierarchy. 

Three type of visualization seem like good possibilities: 
Sankey graphs
Treemaps
Sunburst graphs. 

Sankey graphs show magnitude and break units up into their constituent pieces. However these are usually used to show the flow of quantity either between states or locations. That doesn't mean we can't use them but since there is not a spatial relation here, it might not be the best option. With 10 topics and 26 attributes this would also result in 260 lines and would likely be cluttered/confusing. 

Treemaps recursively subdivide quantities into proportionally sized rectangles. This could work to help see the constituent parts of a group. I also lke this because I think people are better at comparing the size of rectangles to other shapes vis a vis sunburst graphs. 

Sunburst graphs are similar to treemaps except they are in a radial pattern. I think it is more difficult to compare sizes between different arc-shaped sections, but I think it is better at showing heirarchy than the treemap. 

I'm going to attempt to build a treemap for the "base case" of this dataset - the Total column. 

Once that is complete I will try to expand the selection to build a treemap for each of the other columns. Ideally a user would select which column they want to see by clicking or selecting it. 

I think that rows will be more difficult to visualize because they add up to more than 100%. I would need to do some data manipulation to get the proportion of each attribute by "most important" selection. That is, for the "Economy" topic, the "7.00%" value of Age: 18-29 represents that proportion of the age cohort, not the proportion of those to selected "Economy". 

I'll let you know how it goes. 

... 

Yeah that did not work so well. It seems like the treemap functions in d3 want the data to be nested a bit differently than this CSV file is.

Gonna try some stacked bar charts and see if that works any better. 

Don't understand how the group headings are coming in with the .csv file when I've deleted them from the sheet. 

Also, I find it weird that we are getting fractional numbers. if there are 182 people aged 18-29 and 7% of them rated the Economy first, that comes out to 12.74 people. How do you get 3/4 of a person? 

Gonna turn this csv into a json just for kicks. 

Also transposing the data, which seems way easier to do in Excel than in D3. Now each row tells me what is most important to that cohort. 




